import csv
import pymysql
import datetime
import numpy as np

conn = pymysql.connect(host='localhost', user='root', password='1234', db='new_schema')
curs = conn.cursor()

sql= "insert into room_sttus (ROOM_NO, MESURE_DE,MESURE_TIME,TP,LIGHT_QY,DCBL,CO2_DNSTY,PIR) values(%s,%s,%s,%s,%s,%s,%s,%s)"
# sql_5 = "insert into room_sttus (ROOM_NO, MESURE_DE,MESURE_TIME,CO2_DNSTY) values(%s,%s,%s,%s)"
# sql_67 = "insert into room_sttus (ROOM_NO, MESURE_DE,MESURE_TIME,PIR) values(%s,%s,%s,%s)"
f = open('Occupancy_Estimation.csv', 'r')
rd = csv.reader(f)



room_array =  np.zeros((7, 8))
# 인덱스 관리할 배열 


header = next(rd)
# 첫줄 읽어와서

for i in range(header.__sizeof__()):
    if header[i].endswith('_Temp'):
        print('1-', header[i], ',', i)
    elif header[i].endswith('_Light'):
        print('2-', header[i], ',', i)
    elif header[i].endswith('_Sound'):
        print('3-', header[i], ',', i)
    elif header[i].find('CO2') > 0:
        print('4-', header[i], ',', i)
    elif header[i].endswith('_PIR'):
        print('5-', header[i], ',', i)



print(room_array)

# for i in range(len(header)):
#     if header[i].startswith('S1_'):
#         room_array[0].append(i)
#     elif header[i].startswith('S2_'):
#         room_array[1].append(i)
#     elif header[i].startswith('S3_'):
#         room_array[2].append(i)
#     elif header[i].startswith('S4_'):
#         room_array[3].append(i)
#     elif header[i]==('S5_CO2'):
#         room_array[4].append(i)
#     elif header[i].startswith('S6_'):
#         room_array[5].append(i)
#     elif header[i].startswith('S7_'):
#         room_array[6].append(i)z
# col_index = 3
# print(room_array[0])
# for i in range(len(header)):
#     if header[i].startswith('S1_'):
#         room_array[0][col_index] = i
#         col_index += 1


print(room_array[0])
    
# for line in rd:
    
    
#     #   위 코드 잘동작
#     curs.execute(sql , ())   



# conn.commit()
# conn.close()
# f.close()