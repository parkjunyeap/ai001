import csv
import pymysql
import datetime

conn = pymysql.connect(host='localhost', user='root', password='1234', db='new_schema')
curs = conn.cursor()

sql_1234 = "insert into room_sttus (ROOM_NO, MESURE_DE,MESURE_TIME,TP,LIGHT_QY,DCBL) values(%s,%s,%s,%s,%s,%s)"
sql_5 = "insert into room_sttus (ROOM_NO, MESURE_DE,MESURE_TIME,CO2_DNSTY) values(%s,%s,%s,%s)"
sql_67 = "insert into room_sttus (ROOM_NO, MESURE_DE,MESURE_TIME,PIR) values(%s,%s,%s,%s)"
f = open('Occupancy_Estimation.csv', 'r')
rd = csv.reader(f)

room_array = []

header = next(rd)

# for i in range(header.__sizeof__()):
#     if header[i].endswith('_Temp'):
#         print('1-', header[i], ',', i)
#     elif header[i].endswith('_Light'):
#         print('2-', header[i], ',', i)
#     elif header[i].endswith('_Sound'):
#         print('3-', header[i], ',', i)
#     elif header[i].find('CO2') > 0:
#         print('4-', header[i], ',', i)
#     elif header[i].endswith('_PIR'):
#         print('5-', header[i], ',', i)

room_array =  [[0 for col in range(0)] for row in range(7)]


for i in range(len(header)):
    if header[i].startswith('S1_'):
        room_array[0].append(i)
    elif header[i].startswith('S2_'):
        room_array[1].append(i)
    elif header[i].startswith('S3_'):
        room_array[2].append(i)
    elif header[i].startswith('S4_'):
        room_array[3].append(i)
    elif header[i]==('S5_CO2'):
        room_array[4].append(i)
    elif header[i].startswith('S6_'):
        room_array[5].append(i)
    elif header[i].startswith('S7_'):
        room_array[6].append(i)

print(room_array)

print(room_array[0][0])
    
for line in rd:
    
    # curs.execute(sql_1234 , (1, line[0], line[1], line[room_array[0][0]] , line[room_array[0][1]], line[room_array[0][2]]) )
    # curs.execute(sql_1234 , (2, line[0], line[1], line[room_array[1][0]] , line[room_array[1][1]], line[room_array[1][2]]) )
    #   위 코드 잘동작
    curs.execute(sql_1234 , (3, line[0], line[1], line[room_array[2][0]] , line[room_array[2][1]], line[room_array[2][2]]) )   
    curs.execute(sql_1234 , (4, line[0], line[1], line[room_array[3][0]] , line[room_array[3][1]], line[room_array[3][2]]) )
    curs.execute(sql_5 ,    (5, line[0], line[1], line[room_array[4][0]]) )
    curs.execute(sql_67 ,   (6, line[0], line[1], line[room_array[5][0]]) )
    curs.execute(sql_67 ,   (7, line[0], line[1], line[room_array[6][0]]) )



conn.commit()
conn.close()
f.close()