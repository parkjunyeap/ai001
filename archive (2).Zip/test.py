import csv
import pymysql  # 또는 다른 데이터베이스 라이브러리
import datetime

conn = pymysql.connect(host='localhost', user='root', password='1234', db='new_schema')
curs = conn.cursor()

sql = "insert into room_possesn (MESURE_DE,MESURE_TIME,possesn_co) values(%s,%s,%s) ON DUPLICATE KEY UPDATE possesn_co = %s"

f = open('Occupancy_Estimation.csv', 'r')
rd = csv.reader(f)
# header = next(rd)
next(rd)  # 첫 번째 행은 헤더이므로 건너뜁니다
for line in rd:
    print(line[0], line[1] ,line[18])
    curs.execute(sql, (line[0], line[1] ,line[18] , line[18]))


conn.commit()
conn.close()
f.close()
